// 可以完全按照 JavaScript 标准语法编写代码

const hello = (name: any) =>  {
  console.log(`Hello, ${name}`)
}

hello('TypeScript')
