module.exports = {
  testURL: 'http://localhost:8000',
};
