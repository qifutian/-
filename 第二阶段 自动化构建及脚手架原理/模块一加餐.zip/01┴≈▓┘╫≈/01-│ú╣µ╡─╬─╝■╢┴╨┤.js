/**
 * 当前我们想使用 js 来操作文件，（第一我们在node.js 平台下，第二我们需要使用这个平台所提供的模块）
 */
const fs = require('fs')

// 完成文件的读操作（）
// 在实际开发中，路径我们建议使用绝对
// fs.readFile('test.txt', (err, data) => {
//   console.log(data.toString())
// })

// 文件的写操作（）
/* fs.writeFile('test.txt', '就是他，一个lg', (err) => {
  console.log('写入操作完成了')
}) */

// console.log(process.env)