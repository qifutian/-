/**
 * 需求：利用已有的 API 来实现一个自己的可读流（ 数据的生产者 ）
 *
 * 01 继承 stream 模块中的 Readable
 * 02 实现内部的接口方法 _read()
 *
 */
const { Readable } = require('stream')

// 此处定义一个数组用于模拟底层数据，将来供可读流使用
let dataArr = ['zce', 'zcegg', 'isujs', 'syy']

class MyReadable extends Readable {
  constructor(source) {
    super()
    // 可读流就是生产数据的人，因此我们这里可以自己来定义一段数据用于模拟 “底层数据”
    this.source = source
  }
  // 如果想要实现可读流，就必须实现 Readable 内部的一个接口 _read() 
  _read() {
    // 在这个方法的内容如何去创造数据呢？你手里有的的是一个 source,它是一个数组
    // 内部的逻辑是：调用 push 方法，将数据 push 至缓冲区中，此时就相当于产生了数据
    // 将来底层数据肯定有 push 完的时候，此时就给push 传入一个 null ，它自己就会知道数据生产完了
    // 此后就等着别人来消耗它

    let data = this.source.pop() || null
    // 此时我们需要理解 data 将来可能是null 表示没有数据了
    this.push(data)
  }
}

// 此时我的 rs 就是一个可读流，它就能做为数据源通过 pipe 交给 ws 来进行使用
// 但是我们当前没有手写pipe 也没有手写 ws ，因此我们就通过 API 来验证可读流里是否有数据就行了
let rs = new MyReadable(dataArr)

// nodejs 中消费可读流中的数据一般有二种方式，我们这里就采用 data 事件监听
// 这里之所以能使用 on ，好像又证明了一些事情


// 流操作在后端是非常常见的，如文件读写，网络数据传输（https）
// 在使用的时候我们最常见的场景就是用那些 nodejs 已经实现了的内置核心模块例如我们当前的 fs 
// 需要记住这种模块一般都会继承二个类：一个是 EventEmitter 一个是Stream 
rs.on('data', (chunk) => {
  console.log(chunk.toString())
})

