const inquirer = require('inquirer')

/**
 * 01 当前的包可以提供在命令行当中做交互的功能
 * 02 我们只需要分为二步：将需要交互的问题信息准备好、调用 prompt 方法来处理这个问题即可
 * 03 当前的 prompt 返回的是一个 promise ， then
 * 
 * 04 在inquirer 当中可以处理不同类型的问题，同时这些问题的格式都有一些类似，我们通过对象进行管理就可以了
 */

// 01 准备问题
let quesList = [
  {
    type: 'input',
    name: 'useName',
    message: '请输入您的用户名'
  }
]
// 02 处理问题获取结果
inquirer.prompt(quesList).then((answer) => {
  console.log(answer)
})