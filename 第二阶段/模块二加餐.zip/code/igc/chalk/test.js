const chalk = require('chalk')

// 1 修改文字颜色
// console.log(chalk.green('zce'))
// console.log(chalk.red('zcegg'))
// console.log(chalk.gray('圈圈'))

// 2 添加背景颜色
// console.log(chalk.bgCyan(chalk.red('我不道是什么颜色')))

// 3 段落文字样式设置
console.log(chalk.bold`
  {green 从前我很瘦}
  {red 一天还可以吃三顿}
`)