const ora = require('ora')

let spinner = ora('正在下载.....')
spinner.start()
// 耗时时代码
setTimeout(() => {
  console.log('要慢慢的秀')
  // success fail warn info 
  spinner.fail('下载成功了')
}, 2000)

/**
 * 01 ora 一个第三方的工具包，可以实现 loading
 * 02 实例化对象，调用 start 开始，然后执行耗时操作，最后给出结束状态
 */